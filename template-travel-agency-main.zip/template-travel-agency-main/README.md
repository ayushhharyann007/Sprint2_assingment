# template-travel-agency
![viewfinal](https://github.com/ladan-hazrati-web/template-travel-agency/assets/119695832/e19e9e58-0c9a-4eca-9deb-7a0a04972fcc)
**You can see information about my project**

- [Demo Project]( https://ladan-hazrati-web.github.io/template-travel-agency/)

- Developed by ladan hazrati

- Created - 2023-11-01

- Technologies Used - Html , css , Tailwind

- Hooks Used : useState 

- Role - Frontend

- How to reach me : with my [instagram](https://www.instagram.com/ladan_hazrati_web) and [linkedin](https://www.linkedin.com/in/ladan-hazrati-web)
